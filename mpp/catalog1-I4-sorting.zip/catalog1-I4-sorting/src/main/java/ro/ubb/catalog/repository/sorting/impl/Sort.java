package ro.ubb.catalog.repository.sorting.impl;

/**
 * Created by radu.
 */
public class Sort {
    //TODO: implement sorting
}
